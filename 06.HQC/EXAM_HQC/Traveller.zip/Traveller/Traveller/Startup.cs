﻿using Traveller.Core;

namespace Traveller
{
    public class Startup
    {
        public static void Main(string[] args)
        {
            Engine.Instance.Start();
        }
    }
}
