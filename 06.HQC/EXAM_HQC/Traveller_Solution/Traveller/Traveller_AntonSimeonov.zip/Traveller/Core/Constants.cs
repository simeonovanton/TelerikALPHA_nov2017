﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Traveller.Core
{
    public class Constants
    {
        public virtual string TerminationCommand => "Exit";
        public virtual string NullProvidersExceptionMessage => "cannot be null.";
    }
}
