Thanks for downloading this Castle package.
You can find full list of changes in CHANGELOG.md

Documentation (work in progress, contributions appreciated):
DictionaryAdapter:  https://github.com/castleproject/Core/blob/master/docs/dictionaryadapter.md
DynamicProxy:       https://github.com/castleproject/Core/blob/master/docs/dynamicproxy.md
Discusssion group:  http://groups.google.com/group/castle-project-users
StackOverflow tags: castle-dynamicproxy, castle-dictionaryadapter, castle

Issue tracker:      https://github.com/castleproject/Core/issues