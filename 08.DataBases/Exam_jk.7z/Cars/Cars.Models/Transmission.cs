﻿namespace Cars.Models
{
    using System;

    public enum Transmission
    {
        Manual,
        Automatic
    }
}
