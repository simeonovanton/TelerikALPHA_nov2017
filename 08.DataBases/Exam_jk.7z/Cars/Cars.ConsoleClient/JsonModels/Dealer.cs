﻿namespace Cars.ConsoleClient.JsonModels
{
    using System;

    public class JsonDealer
    {
        public string Name { get; set; }

        public string City { get; set; }
    }
}
