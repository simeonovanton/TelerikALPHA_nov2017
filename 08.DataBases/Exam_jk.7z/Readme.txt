﻿I use MS SQL Server 2012 Developer Edition with the following connection string:

connectionString="Data Source=.;Initial Catalog=StudentsDb;Integrated Security=True" providerName="System.Data.SqlClient" />

If You use other version, please, change it accordingly.
