  SELECT TOP(3) p.ProductName, p.UnitPrice
  FROM Products p
  ORDER BY p.UnitPrice DESC