namespace SocialNetwork.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Friendships1 : DbMigration
    {
        public override void Up()
        {
            RenameTable(name: "dbo.PostUserProfiles", newName: "UserProfilePosts");
            DropPrimaryKey("dbo.UserProfilePosts");
            AddPrimaryKey("dbo.UserProfilePosts", new[] { "UserProfile_Id", "Post_Id" });
        }
        
        public override void Down()
        {
            DropPrimaryKey("dbo.UserProfilePosts");
            AddPrimaryKey("dbo.UserProfilePosts", new[] { "Post_Id", "UserProfile_Id" });
            RenameTable(name: "dbo.UserProfilePosts", newName: "PostUserProfiles");
        }
    }
}
