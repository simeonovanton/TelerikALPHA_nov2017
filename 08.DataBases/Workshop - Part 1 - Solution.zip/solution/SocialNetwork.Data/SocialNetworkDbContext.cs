﻿using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using SocialNetwork.Models;
using System.Data.Common;

namespace SocialNetwork.Data
{
    public class SocialNetworkDbContext : DbContext, ISocialNetworkDbContext
    {
        public SocialNetworkDbContext()
            : base("SocialNetwork")
        {
        }

        public SocialNetworkDbContext(DbConnection connection)
            : base(connection, true)
        {
        }

        public virtual IDbSet<UserProfile> UserProfiles { get; set; }

        public virtual IDbSet<Friendship> Friendships { get; set; }

        public virtual IDbSet<Message> Messages { get; set; }

        public virtual IDbSet<Image> Images { get; set; }

        public virtual IDbSet<Post> Posts { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<ManyToManyCascadeDeleteConvention>();

            modelBuilder.Entity<Friendship>().HasRequired(x => x.FirstUser).WithMany(x => x.FriendshipsSent).HasForeignKey(m => m.FirstUserId).WillCascadeOnDelete(false);
            modelBuilder.Entity<Friendship>().HasRequired(x => x.SecondUser).WithMany(x => x.FriendshipsReceived).HasForeignKey(m=>m.SecondUserId).WillCascadeOnDelete(false);

            modelBuilder.Entity<UserProfile>().HasMany(x => x.Posts).WithMany(x => x.TaggedUsers);

            base.OnModelCreating(modelBuilder);
        }
    }
}
