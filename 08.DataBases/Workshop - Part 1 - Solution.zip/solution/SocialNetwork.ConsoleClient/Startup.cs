﻿using SocialNetwork.Data;
using SocialNetwork.Data.Migrations;
using System.Data.Entity;

namespace SocialNetwork.ConsoleClient
{
    public class Startup
    {
        public static void Main()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<SocialNetworkDbContext, Configuration>());
        }
    }
}
