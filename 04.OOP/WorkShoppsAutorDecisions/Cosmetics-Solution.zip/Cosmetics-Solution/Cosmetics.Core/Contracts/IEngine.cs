﻿namespace Cosmetics.Core.Contracts
{
    public interface IEngine
    {
        void Start();
    }
}
