﻿using Cosmetics.Core.Engine;

namespace Cosmetics
{
    public class CosmeticsProgram
    {
        public static void Main()
        {
            CosmeticsEngine.Instance.Start();
        }
    }
}
