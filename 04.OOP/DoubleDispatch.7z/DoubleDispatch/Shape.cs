﻿namespace DoubleDispatch
{
	public class Shape
	{
	}
}
