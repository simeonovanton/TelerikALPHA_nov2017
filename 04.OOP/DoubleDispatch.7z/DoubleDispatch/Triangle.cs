﻿namespace DoubleDispatch
{
	public class Triangle : Shape
	{
	}
}
