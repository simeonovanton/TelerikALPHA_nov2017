﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agency.Models
{

    public enum VehicleType
    {
        Land,
        Air,
        Sea
    }

}